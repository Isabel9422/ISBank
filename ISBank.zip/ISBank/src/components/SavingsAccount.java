package components;

public class SavingsAccount extends Account{

	public SavingsAccount(String label, Client client) {
		super(label, client);
	}

}
