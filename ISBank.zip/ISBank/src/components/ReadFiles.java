package components;
import java.io.IOException;
import java.io.Reader;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.awt.Window.Type;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class ReadFiles{
		
	public static void writeFileJson(ArrayList<Flow> flows) {		
		
		File file = new File("src\\componentTest\\flow.json");
		String json= flows.toString();
		
        if (!file.exists()) { try {
			file.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}}
		
        Path path = Paths.get("src\\componentTest\\flow.json");
        System.out.println(json);
        
		try {
			Files.readAllLines(path).toString();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Gson gson = new Gson();
				
        String jsonString = gson.toJson(flows);
        
        System.out.println(jsonString);
		
		
        try (Reader reader = new FileReader("staff.json")) {

            // Convert JSON File to Java Object
             Debit staff = gson.fromJson(reader, Debit.class);
			
			// print staff 
            System.out.println(" aqui estas : "+staff);
            flows.add(staff);
            System.out.println("OBJETO AÑADIDO" + flows.get(16).toString());

        } catch (IOException e) {
            e.printStackTrace();
        }	
	}
}