package components;

public class CurrentAccount extends Account{

	public CurrentAccount(String label, Client client) {
		super(label, client);
	}
}
